# gala game

一个完全离线的 Android 小应用：
- 应用名称：gala game
- 启动后只显示提供的照片
- 不联网
- 不申请任何运行时权限
- 照片同时作为应用图标

## 构建
用 Android Studio 打开本目录，等待 Gradle 同步，然后选择：
Build -> Generate App Bundle(s) / APK(s) -> Generate APK(s)

项目使用 Android Gradle Plugin 9.4.0；对应 Gradle 版本建议使用 9.6.0，JDK 17。
